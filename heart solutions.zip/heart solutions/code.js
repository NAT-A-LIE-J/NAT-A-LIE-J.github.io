var mouseovers = 0;

onEvent("noButton", "mouseover", function( ) {
	setPosition("noButton", randomNumber(50,280), randomNumber(50, 400));
	mouseovers = mouseovers +1;
	
	
	 if (mouseovers > 10) {
showElement("yesButton");
}

});








onEvent("yesButton", "click", function( ) {
 
 
 
 
for (var i = 0; i < 34; i++) {
  
  showheart("heart" + i,i);
  // enlarge("heart"+i); 
  }
  
  
  // loop to go through all the hearts
  for (var c = 0; c < 34; c++) {
  pop("heart" + c,c);
  }
  
  
  
  
  
  
  
  
  
  
  
});

//function show defined

function showheart(numberheart,i){
  
  setTimeout(function() {
  setPosition("heart"+i, randomNumber(0,320), randomNumber(0, 450));
  setSize("heart"+i,randomNumber(11,51), randomNumber(11, 51) );
  showElement("heart"+i);
  i = i*100;
  i = i*100*100*i*i*i*i*i*i*i*i;
   }, 100+i);
  
} 

// function pop defined
function pop(numberheart,c){
  setTimeout(function() {
    c = c*c*100*c*c*c*c*c*c*c*c*c*c*c*c*c;
 
    hideElement(numberheart);
    console.log(numberheart + " is popepd");
       
   }, 1500+c);
}













/* function enlarge(numberheart) {
   setTimeout(function() {
                                        
                                     x = getWidth
                                      setSize(numberheart,x+1,y+1 );
                                    
                                      }, 100);
}

      */                              
                                    
                                    




 

